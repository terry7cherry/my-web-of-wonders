export default class ScrollingTextBox {
    constructor(elementId) {
        this.textBox = document.getElementById(elementId);
        this.table = document.createElement("table");
        this.textBox.appendChild(this.table);
        Array(Math.ceil(this.textBox.clientHeight/6))
            .fill("                    ")
            .forEach(text => this.addText(text));
        this.textBox.scrollTop = this.textBox.scrollHeight;
    }

    addText(text) {
        const scrolledToBottom = this.textBox.scrollTop >= this.textBox.scrollHeight - this.textBox.clientHeight;
        if(this.table.children.length >= 200) this.table.removeChild(this.table.firstChild);
        const newRow = document.createElement("tr");
        if(!Array.isArray(text)) text = [text];
        newRow.innerHTML = text.map(c => `<td>${c.toString().replace(/\\n/g, "")}</td>`).join("");
        this.table.appendChild(newRow);
        if(scrolledToBottom) this.textBox.scrollTop = this.textBox.scrollHeight;
    }
}